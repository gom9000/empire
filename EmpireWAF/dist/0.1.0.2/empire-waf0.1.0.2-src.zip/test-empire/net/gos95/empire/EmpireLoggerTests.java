package net.gos95.empire;


import net.gos95.empire.logger.LoggerTest;
import junit.framework.Test;
import junit.framework.TestSuite;


public class EmpireLoggerTests
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("Test for net.gos95.empire.logger");

		//$JUnit-BEGIN$
		suite.addTestSuite(LoggerTest.class);
		//$JUnit-END$
		return suite;
	}
}
