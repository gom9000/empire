package net.gos95.empire.logger;

import net.gos95.empire.logger.Logger;
import junit.framework.TestCase;

public class LoggerTest
extends TestCase
{
	private Logger logger;
	private String propFile = "etc\\logger.properties";
	private String logFile = "reports\\logger.log";
	private String alias1 = "logfile1";
	private String alias2 = "logfile2";

	public LoggerTest(String name)
	{
		super(name);
	}

	protected void setUp()
	throws Exception
	{
		super.setUp();
		logger = new Logger(propFile, logFile);
	}


	public void testLogger()
	{
		logger.write("this is a message!!!", alias1);
		//assertFalse(logger.isLogFull(alias2));
		//while (!logger.isLogFull(alias2))
		for (int ii=0; ii<2000; ii++) {
		    logger.write("01234567890123456789012345678901234567890123456789", alias2);
		    try {
				Thread.sleep(10);
			} catch (InterruptedException ignore) {}
		}
	}
}
