package net.gos95.empire.util.support;


import net.gos95.empire.util.TimeoutTimer;


public class TimeoutTimerExtends
extends TimeoutTimer
{
	public boolean actionPerformed = false;


	public TimeoutTimerExtends(int timeuot)
	{
		super(timeuot);
	}


	public void action()
	{
		actionPerformed = true;
	}
}
