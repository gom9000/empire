/*
 * E  M  P  I  R  E    W A F   Library
 *   ________        _________________.________
 *  /  _____/  ____ /   _____/   __   \   ____/
 * /   \  ___ /  _ \\_____  \\____    /____  \
 * \    \_\  (  <_> )        \  /    //       \
 *  \______  /\____/_______  / /____//______  /
 *         \/              \/               \/
 * Copyright (c) 2007 2009 by
 * Alessandro Fraschetti (gos95@gommagomma.net)
 * 
 * This file is part of the Empire WAF library.
 * For more information about Empire WAF visit:
 *     http://gommagomma.net/gos95/Empire
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 */


package net.gos95.empire.waf.util.session;


import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.http.HttpSession;

import net.gos95.empire.lang.EmpireObject;
import net.gos95.empire.logger.Logger;


/**
 * The <code>SessionMonitor</code> class implements a user session monitor.<br>
 * Stored user session info are:<PRE>
 *  username         - identify the connected user
 *  applicationAlias - application alias
 *  session          - the user session object
 *  creationDate     - creation date of record in monitor
 *  lastRequestDate  - last user request date
 *  ip               - user client ip address
 *  obj              - a generic object attached to user session
 * </PRE>
 * @author  Alessandro Fraschetti
 * @version 1.1, 29/01/2006
 * @see     net.gos95.empire.waf.util.session.SessionData
 * @since   1.3
 */
public class SessionMonitor
extends EmpireObject
{
	private static final long serialVersionUID = 101L;

	private Hashtable hash;
    private Hashtable hashSess;


    /**
     * Creates a new empty <code>SessionMonitor</code> object.
     */
    public SessionMonitor()
    {
    	super(Logger.class, serialVersionUID);
        hash = new Hashtable();
        hashSess = new Hashtable();
    }


    /**
     * Adds (or replaces if exists) a new session entry with the specified info. 
     *
     * @param  username the username of the user
     * @param  session  the user session object
     * @param  ip       the user client ip address
     * @param  obj      a generic object
     */
    public synchronized void addSession(String username, HttpSession session, String ip, Object obj)
    {
        SessionData data = new SessionData();

        data.username        = username;
        data.session         = session;
        data.ip              = ip;
        data.obj             = obj;
        data.creationDate    = new Date();
        data.lastRequestDate = new Date(session.getCreationTime());

        hash.put(username, data);
        hashSess.put(username, session);
    }


    /**
     * Adds (or replaces if exists) a new session entry with the specified info. 
     *
     * @param  username the username of the user
     * @param  session  the user session object
     * @param  ip       the user client ip address
     */
    public synchronized void addSession(String username, HttpSession session, String ip)
    {
        addSession(username, session, ip, null);
    }


    /**
     * Removes from monitor session data of the given username.
     *
     * @param  username the username of the user
     */
    public void removeSession(String username)
    {
        if (hash.containsKey(username))
        {
            hash.remove(username);
            hashSess.remove(username);
        }
    }


    /**
     * Tests if monitor contains the specified username.
     *
     * @param  username the username of the user
     * @return the boolean result of test
     */
    public boolean containsUsername(String username)
    {
        return hash.containsKey(username);
    }


    /**
     * Tests if monitor contains the specified user session object.
     *
     * @param  session user session object
     * @return the boolean result of test
     */
    public boolean containsSession(HttpSession session)
    {
        return hashSess.containsValue(session);
    }


    /**
     * Returns the session object by the username.
     *
     * @param  username user username
     * @return user session object
     */
    public HttpSession getSession(String username)
    {
        return ((SessionData)hash.get(username)).session;
    }


    /**
     * Returns the username by the user session object.
     *
     * @param  session  user session object
     * @return user username
     */
    public String getUsername(HttpSession session)
    {
        String username;

        for (Enumeration e=hash.keys(); e.hasMoreElements(); )
        {
            username = (String)e.nextElement();
            if (session.equals(((SessionData)hash.get(username)).session))
                return username;
        }

        return "";
    }


    /**
     * Updates user last http-request date by the userame.
     *
     * @param  username  user username
     */
    public synchronized void updateLastHttpRequestDate(String username)
    {
        SessionData data = (SessionData)hash.get(username);
        data.lastRequestDate = new Date();
        hash.put(username, data);
    }


    /**
     * Updates user last request date by the session object.
     *
     * @param  session  user session object
     */
    public synchronized void updateLastHttpRequestDate(HttpSession session)
    {
        updateLastHttpRequestDate(getUsername(session));

    }


    /**
     * Returns the user session creation date.
     *
     * @param  username  user username
     * @return the user session creation date
     */
    public Date getSessionDate(String username)
    {
        return ((SessionData)hash.get(username)).creationDate;
    }


    /**
     * Returns the user last request date.
     *
     * @param  username  user username
     * @return user last request date
     */
    public Date getLastRequestDate(String username)
    {
        return ((SessionData)hash.get(username)).lastRequestDate;
    }


    /**
     * Sets the user client ip address.
     *
     * @param  username  user username
     * @param  ip        user client ip address
     */
    public synchronized void setIP(String username, String ip)
    {
        SessionData data = (SessionData)hash.get(username);
        data.ip = ip;
        hash.put(username, data);
    }


    /**
     * Returns the user client ip address.
     *
     * @param  username  user username
     * @return user client ip address
     */
    public String getIP(String username)
    {
        return ((SessionData)hash.get(username)).ip;
    }


    /**
     * Returns a string representation of this object.
     * 
     * @return string representation of this object
     */
    public String toString()
    {
        return hash.toString();
    }
}
