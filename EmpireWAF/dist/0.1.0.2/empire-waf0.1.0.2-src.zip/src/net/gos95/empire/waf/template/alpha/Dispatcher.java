/*
 * E  M  P  I  R  E    W A F   Library
 *   ________        _________________.________
 *  /  _____/  ____ /   _____/   __   \   ____/
 * /   \  ___ /  _ \\_____  \\____    /____  \
 * \    \_\  (  <_> )        \  /    //       \
 *  \______  /\____/_______  / /____//______  /
 *         \/              \/               \/
 * Copyright (c) 2007 2009 by
 * Alessandro Fraschetti (gos95@gommagomma.net)
 * 
 * This file is part of the Empire WAF library.
 * For more information about Empire WAF visit:
 *     http://gommagomma.net/gos95/Empire
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 */


package net.gos95.empire.waf.template.alpha;



import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.gos95.empire.util.ObjectListManager;
import net.gos95.empire.waf.servlet.EmpireServlet;
import net.gos95.empire.waf.util.messages.Message;
import net.gos95.empire.waf.util.messages.MessageBox;
import net.gos95.empire.waf.util.navigator.Navigator;
import net.gos95.empire.waf.util.navigator.Route;


/**
 * The <code>Dispatcher</code> servlet class manages routing dispatch
 * from client to competent controller objects, according to contents
 * of <code>Navigator</code> object.
 *
 * @author  Alessandro Fraschetti
 * @version 1.0, 01/02/2006
 * @since   1.3
 */
public class Dispatcher
extends net.gos95.empire.waf.template.alpha.Servlet
{
	/* the class-version of this class */
	private static final long serialVersionUID = 100L;


    /**
     * Calls parent init method.
     */
    public void init() 
    {
        super.init();
    }


    /**
     * Alpha template implementation of Dispatcher method doPost.<br>
     * Dispatch the client request to competent Controller, according
     * to contents of Navigator object.
     * 
     * @param  req the servlet request object
     * @param  res the servlet response object
     */
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException
    {
        String            httpParameter = req.getParameter(Navigator.PARAMETER);
        String            httpStep      = req.getParameter(Navigator.STEP);
        HttpSession       session       = req.getSession();
        RequestDispatcher rd            = null;
        String username                 = "";
        String controllerUrl            = "";

        try {

        	// if session not contains sessionOLM, creates it and
        	// creates a new empty Navigator with only login and logout routes.
            if (req.getSession().getAttribute("sessionOLM") == null)
            {
                sessionOLM = new ObjectListManager();
                navigator = new Navigator(getServletContext().getInitParameter("dispatcherURL"));

                // add LOGIN route
                Route r = new Route();
                r.code   = "login";
                r.name   = "Login";
                r.id     = -100;
                r.enable = true;
                navigator.addRoute(r);

                // add LOGOUT route
                Route r2  = new Route();
                r2.code   = "logout";
                r2.name   = "Logout";
                r2.id     = -101;
                r2.enable = true;
                navigator.addRoute(r2);

                sessionOLM.add("navigator", navigator);
                req.getSession().setAttribute("sessionOLM", sessionOLM);
            }

            // retrieve sessionOLM and Navigator from session
            sessionOLM = (ObjectListManager)req.getSession().getAttribute("sessionOLM");
            navigator = (Navigator)sessionOLM.get("navigator");

            // sets the current route
            navigator.setCurrentRoute(httpParameter, httpStep);

            // "steady" navigation, or "out-loop" navigation (login or logout route requested)
            if (!httpParameter.equals("login") && !httpParameter.equals("logout"))
            {
                // tests user session to retrieve navigation info
                if (monitor.containsSession(session))
                {
                    monitor.updateLastHttpRequestDate(session);
                    username = monitor.getUsername(session);
                    controllerUrl = navigator.getControllerUrl();
                } else {
                    String messageControllerUrl = getServletContext().getInitParameter("messageControllerURL");
                    String message = getServletContext().getInitParameter("sessionErrorMessage");
                    MessageBox mb = new MessageBox();
                    mb.setMessage(new Message(0, "sessionErrorMessage", message, Message.ERROR));
                    mb.addAction("ok", "logout");
                    ControllerException ctrle = new ControllerException(mb);
                    rd = req.getRequestDispatcher(messageControllerUrl);
                    req.setAttribute("exception", ctrle);
                    rd.forward(req, resp);
                    return;
                }
            } else {
                controllerUrl = getServletContext().getInitParameter("accessControllerURL");
            }

            // log request into dispatcher log
            log.write("username="+username+", httpParameter="+httpParameter+((httpStep==null)?"":"#"+httpStep), "dispatcher");

            // dispatch request to competent controller
            rd = req.getRequestDispatcher(controllerUrl);
            rd.forward(req, resp);

        } catch(Exception e) {

            // servlet error
            log.write("(Dispatcher)" + e.toString() + " - " + e.getMessage(), "ewaf-errors");

            try {
                // dispatch to MessageController
                String messageControllerUrl = getServletContext().getInitParameter("messageControllerURL");
                rd = req.getRequestDispatcher(messageControllerUrl);
                //req.setAttribute("exception", e);
                rd.forward(req, resp);
            } catch(IOException ioe) {
                log.write("(Dispatcher)" + ioe.toString(), "ewaf-errors");
                String message = getServletContext().getInitParameter("servletErrorMessage");
                debug(req, resp, message + "<br>" + ioe.toString());
            }
        }

    }


    /**
	 * Returns class-version.
	 */
	public String version()
	{
		return "EmpireWAF" + EmpireServlet.version + "/" + getClass().getName() + ((float)serialVersionUID/100);
	}
}
