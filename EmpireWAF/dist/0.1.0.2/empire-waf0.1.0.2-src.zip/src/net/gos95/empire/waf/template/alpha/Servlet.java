/*
 * E  M  P  I  R  E    W A F   Library
 *   ________        _________________.________
 *  /  _____/  ____ /   _____/   __   \   ____/
 * /   \  ___ /  _ \\_____  \\____    /____  \
 * \    \_\  (  <_> )        \  /    //       \
 *  \______  /\____/_______  / /____//______  /
 *         \/              \/               \/
 * Copyright (c) 2007 2009 by
 * Alessandro Fraschetti (gos95@gommagomma.net)
 * 
 * This file is part of the Empire WAF library.
 * For more information about Empire WAF visit:
 *     http://gommagomma.net/gos95/Empire
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 */


package net.gos95.empire.waf.template.alpha;


import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gos95.empire.util.ListManager;
import net.gos95.empire.util.ObjectListManager;
import net.gos95.empire.logger.Logger;
import net.gos95.empire.waf.servlet.EmpireServlet;
import net.gos95.empire.waf.util.messages.MessageManager;
import net.gos95.empire.waf.util.navigator.Navigator;
import net.gos95.empire.waf.util.session.SessionMonitor;

// TODO WAF - alpha.Servlet docs.
// TODO WAF - alpha.Template Test.
/**
 * The <code>Servlet</code> servlet class is the tag and root class
 * of Empire WAF "alpha" template.<br>
 * This class defines some implicit object...
 *
 * @author  Alessandro Fraschetti
 * @version 1.0, 07/12/2007
 * @see     gos95.empire.util.ListManager
 * @see     gos95.empire.util.logger.Logger
 * @see     net.gos95.empire.waf.servlet.EmpireServlet
 * @see     net.gos95.empire.waf.util.messages.MessageManager
 * @see     net.gos95.empire.waf.util.navigator.Navigator
 * @see     net.gos95.empire.waf.util.session.SessionMonitor
 * @since   1.3
 */
public abstract class Servlet
extends EmpireServlet
{
	private static final long serialVersionUID = 100L;


    /** Implicit reference to the navigation object */
    public Navigator navigator;

    /** Implicit reference to the session monitor */
    public SessionMonitor monitor;

    /** Implicit reference to the message manager */
    public MessageManager messages;

    /** Implicit reference to the logger */
    public Logger log;


    /**
     * Initializes servlet implicit objects.
     */
    public void init()
    {
        ServletContext ctx = getServletContext();

        // retrieves OLM server (created elsewhere)
        // TODO XNEW - WAF - alpha.Servlet: init - retrieve server OLM

        // inits (only 1 time) and popolates the application OLM
        if (ctx.getAttribute("OLMApplicationInitialized") == null)
            initialize();

        // retrieves implicit objects from application OLM
        applicationOLM = (ListManager)ctx.getAttribute("OLM");
        monitor = (SessionMonitor)applicationOLM.get("monitor");
        messages = (MessageManager)applicationOLM.get("messages");
        log = (Logger)applicationOLM.get("logger");
    }


    // init "application" objects
    private void initialize()
    {
        ServletContext ctx = getServletContext();

        // init the session monitor
        monitor = new SessionMonitor();

        // init the message manager
        messages = new MessageManager();

        // init the logger
        // TODO XNEW - WAF - alpha.Servlet: init logger from web.xml
        try {
            log = new Logger(ctx.getInitParameter("loggerConfigFile"),
                             ctx.getInitParameter("loggerLogFile"));
        } catch(Exception e) {e.printStackTrace(System.out);}

        // init the application OLM, and populates it
        ObjectListManager olm = new ObjectListManager();
        olm.add("monitor", monitor);
        olm.add("messages", messages);
        olm.add("logger", log);

        // store the OLM in the application context
        ctx.setAttribute("OLM", olm);
        ctx.setAttribute("OLMApplicationInitialized", new Boolean(true));
    }


    /**
	 * Returns class-version.
	 */
	public String version()
	{
		return "EmpireWAF" + EmpireServlet.version + "/" + getClass().getName() + ((float)serialVersionUID/100);
	}


    /**
     * All servlets in the alpha template must implement this method.
     * 
     * @param  request  the servlet request object
     * @param  response the servlet response object
     * @excption ServletException
     */
    public abstract void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException;
}
