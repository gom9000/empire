/*
 * E  M  P  I  R  E    W A F   Library
 *   ________        _________________.________
 *  /  _____/  ____ /   _____/   __   \   ____/
 * /   \  ___ /  _ \\_____  \\____    /____  \
 * \    \_\  (  <_> )        \  /    //       \
 *  \______  /\____/_______  / /____//______  /
 *         \/              \/               \/
 * Copyright (c) 2007 2009 by
 * Alessandro Fraschetti (gos95@gommagomma.net)
 * 
 * This file is part of the Empire WAF library.
 * For more information about Empire WAF visit:
 *     http://gommagomma.net/gos95/Empire
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, see <http://www.gnu.org/licenses/>.
 */


package net.gos95.empire.waf.template.alpha;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.gos95.empire.waf.servlet.EmpireServlet;
import net.gos95.empire.waf.util.messages.MessageBox;


/**
 * The <code>MessageController</code> servlet class is the tag and root class
 * of Empire WAF "alpha" template servlet message controller.<br>
 * The <code>MessageController</code> manages application and error messages.
 *
 * @author  Alessandro Fraschetti
 * @version 1.0, 01/02/2006
 * @see     net.gos95.empire.waf.template.alpha.Servlet
 * @since   1.3
 */
abstract public class MessageController
extends net.gos95.empire.waf.template.alpha.Servlet
{
	/* the class-version of this class */
	private static final long serialVersionUID = 100L;


    /**
     * References to ControllerException that causes the exception to display.
     */
    public ControllerException exception;


    /**
     * Calls parent init method.
     */
    public void init()
    {
        super.init();
    }


    /**
     * Alpha template implementation of Controller method doPost.<br>
     * Call dispatcher with the message box that incapsulate the message
     * to display and actions to fire. 
     * 
     * @param  req the servlet request object
     * @param  res the servlet response object
     */
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException
    {
        try {
            exception = (ControllerException)req.getAttribute("exception");

            if (exception.getStack().size() > 1) //.equals(""))
                log.write("(MessageController[ControllerException])" + exception.toStackString(), "ewaf-errors");
            MessageBox mbox = exception.getMessageBox();
            dispatcher(mbox, req, resp);
        } catch(Exception e) {
             // errore servlet
             log.write("(MessageController)[Exception]" + e.toString(), "ewaf-errors");
             System.out.println("MessageController[Exception]:");
             e.printStackTrace();
             String message = getServletContext().getInitParameter("servletErrorMessage");
             debug(req, resp, message + "<br>" + e.toString());
        }
    }


    /**
     * The  Message Controller must implement this method.<br>
     * Dispatches message elements to appropriate method.
     *
     * @param mbox the message box to manage
     * @param req  the servlet request object
     * @param resp the servlet response object
     */
    abstract public void dispatcher(MessageBox mbox, HttpServletRequest req, HttpServletResponse resp)
    throws Exception;


    /**
	 * Returns class-version.
	 */
	public String version()
	{
		return "EmpireWAF" + EmpireServlet.version + "/" + getClass().getName() + ((float)serialVersionUID/100);
	}
}
