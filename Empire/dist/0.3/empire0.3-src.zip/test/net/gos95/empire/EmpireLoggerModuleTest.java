/*
 * E  M  P  I  R  E   Library
 *   ________        _________________.________
 *  /  _____/  ____ /   _____/   __   \   ____/
 * /   \  ___ /  _ \\_____  \\____    /____  \
 * \    \_\  (  <_> )        \  /    //       \
 *  \______  /\____/_______  / /____//______  /
 *         \/              \/               \/
 * Copyright (c) 2007 2009 by
 * Alessandro Fraschetti (gos95@gommagomma.net)
 * 
 * This file is part of the Empire library.
 * For more information about Empire visit:
 *     http://gommagomma.net/gos95/Empire
 *
 * Empire library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License as 
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version. 
 *
 * Empire library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, see <http://www.gnu.org/licenses/>.
 */


package net.gos95.empire;


import net.gos95.empire.logger.LoggerTest;
import junit.framework.Test;
import junit.framework.TestSuite;


public class EmpireLoggerModuleTest
{
	// logger test-files...
	static public String testPropLogFile = "test/resources/logger/logger-test.properties";
	static public String testLogLogFile = "reports/logger.log";


	public static Test suite()
	{
		TestSuite suite = new TestSuite("Test for Logger Module");

		//$JUnit-BEGIN$
		suite.addTestSuite(LoggerTest.class);
		//$JUnit-END$
		return suite;
	}
}
