package net.gos95.empire.util;


import net.gos95.empire.util.support.TimeoutTimerExtends;
import junit.framework.Assert;
import junit.framework.TestCase;


public class TimeoutTimerTest
extends TestCase
{
	private TimeoutTimerExtends timer;
	private int timeout = 720;


	public TimeoutTimerTest(String name)
	{
		super(name);
	}

	protected void setUp()
	throws Exception
	{
		super.setUp();
	}


	public void testTimeout()
	{
		timer = new TimeoutTimerExtends(timeout); 
		timer.run();
		Assert.assertTrue(timer.actionPerformed);
		Assert.assertTrue(timer.isFired());
	}
}
